package com.bookstore.backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookstoreBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
